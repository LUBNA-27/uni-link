"""UniLink backend SHELL — owned by Lubna only for health + static serving.
Ranad replaces/extends this with the real engine (routes in master §10). Do not add logic here."""
import os
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

app = FastAPI(title="Jeeny UniLink (prototype)")


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "fixture_version": "none_yet",
        "gemini_ready": bool(os.getenv("GEMINI_API_KEY")),  # never return the secret itself
        "source": "simulation",
    }


# Keep LAST: serves the built React app from the same origin.
DIST = Path(__file__).resolve().parent.parent / "frontend" / "dist"
if DIST.is_dir():
    app.mount("/", StaticFiles(directory=str(DIST), html=True), name="static")
