import { CalendarDays, Route, Sliders, Ticket } from 'lucide-react'
import { StoreProvider, useStore, type View } from './store'
import Schedule from './screens/Schedule'
import Trip from './screens/Trip'
import Journey from './screens/Journey'
import Booked from './screens/Booked'
import { DevDrawer } from './components/DevDrawer'
import { anyMock } from './api'

const STEPS: { view: View; label: string; Icon: typeof Route }[] = [
  { view: 'schedule', label: 'Schedule', Icon: CalendarDays },
  { view: 'trip', label: 'Trip', Icon: Sliders },
  { view: 'journey', label: 'Journey', Icon: Route },
  { view: 'booked', label: 'Pass', Icon: Ticket },
]

function Shell() {
  const { view, go, timetableConfirmed, plan, sim, setDevOpen } = useStore()
  const enabled: Record<View, boolean> = {
    schedule: true,
    trip: timetableConfirmed,
    journey: !!plan,
    booked: !!sim?.trips.length,
  }
  return (
    <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col bg-plum text-white">
      <header className="sticky top-0 z-20 bg-plum/95 px-4 pb-2 pt-3 backdrop-blur">
        <div className="mb-2 flex items-center gap-2">
          <img src="./favicon.svg" alt="" className="size-8" />
          <div className="leading-tight">
            <p className="text-lg font-black tracking-tight">Jeeny <span className="text-lime">UniLink</span></p>
            <p className="text-[11px] font-semibold text-white/60">Campus Commute · prototype</p>
          </div>
        </div>
        <nav aria-label="Progress" className="grid grid-cols-4 gap-1.5">
          {STEPS.map(({ view: v, label, Icon }) => (
            <button key={v} disabled={!enabled[v]} aria-current={view === v ? 'step' : undefined} onClick={() => go(v)}
              className={`flex min-h-12 flex-col items-center justify-center gap-0.5 rounded-xl text-[11px] font-extrabold transition-colors ${
                view === v ? 'bg-lime text-plum' : enabled[v] ? 'bg-plum-2 text-white' : 'bg-plum-2/50 text-white/35'}`}>
              <Icon className="size-4" aria-hidden />{label}
            </button>
          ))}
        </nav>
      </header>

      {anyMock() && (
        <p className="mx-4 mt-2 rounded-lg bg-amber-200 px-3 py-1.5 text-center text-xs font-bold text-plum" role="note">
          Demo build: some screens use temporary MOCK data (not the real engine yet).
        </p>
      )}

      <main className="flex-1 px-4 pb-8 pt-4">
        {view === 'schedule' && <Schedule />}
        {view === 'trip' && <Trip />}
        {view === 'journey' && <Journey />}
        {view === 'booked' && <Booked />}
      </main>

      <footer className="px-4 pb-6 text-center text-xs text-white/55">
        <p>UniLink — hackathon prototype, simulation data.</p>
        <button onClick={() => setDevOpen(true)} className="mt-1 min-h-10 px-3 font-bold underline">Simulation controls</button>
      </footer>
      <DevDrawer />
    </div>
  )
}

export default function App() {
  return (
    <StoreProvider>
      <Shell />
    </StoreProvider>
  )
}
