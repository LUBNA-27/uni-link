import type { ReactNode } from 'react'
import { Accessibility, Check, GraduationCap, MapPin, ShieldAlert } from 'lucide-react'
import { fmtJod, jod } from '../format'
import type { PlanOption } from '../types'
import { useStore } from '../store'
import { Chip } from './ui'

/** Vertical route strip: pickups (closest → farthest) then campus. Pure rendering. */
export function RouteStrip({ option }: { option: PlanOption }) {
  const stops = option.pickups ?? option.pickup_order.map((t, i) => ({
    rider_token: t, landmark: i === 0 ? 'Your pickup' : `Companion pickup ${i}`, time: '', is_you: i === 0,
  }))
  return (
    <ol className="relative ml-1 space-y-3" aria-label="Pickup order">
      <span className="absolute left-[11px] top-3 bottom-8 w-0.5 bg-plum/20" aria-hidden />
      {stops.map((s, i) => (
        <li key={s.rider_token} className="relative flex items-center gap-3">
          <span className={`z-10 grid size-6 shrink-0 place-items-center rounded-full text-[11px] font-black ${s.is_you ? 'bg-magenta text-white' : 'bg-plum text-white'}`}>
            {i + 1}
          </span>
          <span className="min-w-0 flex-1 truncate text-sm font-semibold text-plum">{s.landmark}</span>
          {s.time && <span className="font-black tabular-nums text-plum">{s.time}</span>}
        </li>
      ))}
      <li className="relative flex items-center gap-3">
        <span className="z-10 grid size-6 shrink-0 place-items-center rounded-full bg-lime text-plum"><GraduationCap className="size-3.5" aria-hidden /></span>
        <span className="flex-1 text-sm font-bold text-plum">Campus drop-off</span>
        <span className="font-black tabular-nums text-plum">{option.arrival}</span>
      </li>
    </ol>
  )
}

/** Leg-weighted fair split, exactly as returned by the server. Display only. */
export function SplitList({ option }: { option: PlanOption }) {
  const { riderToken } = useStore()
  const shares = option.fare.shares
  if (!shares || shares.length < 2) return null
  const label = (t: string) => {
    if (t === riderToken) return 'You'
    const p = option.pickups?.find((x) => x.rider_token === t)
    return p ? p.landmark.split(' · ')[0] : t
  }
  return (
    <section aria-label="Fair split" className="rounded-xl bg-white p-3">
      <p className="mb-1.5 text-xs font-bold uppercase text-plum/60">Fair split · each pays for the distance they ride</p>
      <ul className="space-y-1 text-sm">
        {shares.map((r) => (
          <li key={r.rider_token} className={`flex justify-between ${r.rider_token === riderToken ? 'font-black text-magenta' : ''}`}>
            <span>{label(r.rider_token)}</span><span className="tabular-nums">{jod(r.share_fils)}</span>
          </li>
        ))}
      </ul>
      <p className="mt-1.5 text-xs text-plum/60">Vehicle total {jod(option.fare.vehicle_total_fils)} = what the shares add up to (server-computed).</p>
    </section>
  )
}

export function BoardingPass({
  option, heading = 'BOARDING PASS', badge, children, showReference = true,
}: { option: PlanOption; heading?: string; badge?: ReactNode; children?: ReactNode; showReference?: boolean }) {
  const f = option.fare
  const wav = option.vehicle?.wheelchair_accessible
  return (
    <article className="ticket overflow-hidden rounded-3xl bg-lavender text-plum shadow-xl" aria-label="Journey boarding pass">
      <header className="flex items-center justify-between bg-magenta px-5 py-2.5 text-white">
        <span className="text-xs font-black tracking-[0.18em]">UNILINK · {heading}</span>
        {badge}
      </header>

      <div className="p-5">
        <div className="mb-1 flex items-center gap-2 text-xs font-bold uppercase tracking-wide text-plum/60">
          <MapPin className="size-3.5" aria-hidden /> Door-to-Door → Campus
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs font-bold uppercase text-plum/60">Arrive</p>
            <p className="text-5xl font-black leading-none tabular-nums">{option.arrival}</p>
            {option.deadline && <p className="mt-1 text-xs text-plum/60">deadline {option.deadline}</p>}
          </div>
          <div>
            <p className="text-xs font-bold uppercase text-plum/60">Your share</p>
            <p className="text-4xl font-black leading-none tabular-nums text-magenta">
              <span className="mr-1 text-base font-extrabold">JOD</span>{fmtJod(f.your_share_fils)}
            </p>
            <p className="mt-1 text-xs text-plum/60">of {jod(f.vehicle_total_fils)} vehicle total</p>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <Chip tone="soft">Leave home {option.leave_home}</Chip>
          {option.vehicle && (
            <Chip tone={wav ? 'lime' : 'soft'}>
              {wav && <Accessibility className="size-3.5" aria-hidden />} {option.vehicle.label}
            </Chip>
          )}
          {option.flags?.map((fl) => <Chip key={fl} tone="amber">{fl.replaceAll('_', ' ')}</Chip>)}
        </div>
      </div>

      <div className="ticket-cut" aria-hidden />

      <div className="p-5">
        <RouteStrip option={option} />

        {option.accessible_dropoff && (
          <div className={`mt-4 rounded-xl p-3 text-sm ${option.accessible_dropoff.verified ? 'bg-lime/40' : 'bg-amber-100'}`}>
            <p className="flex items-center gap-1.5 font-bold">
              {option.accessible_dropoff.verified ? <Accessibility className="size-4" aria-hidden /> : <ShieldAlert className="size-4" aria-hidden />}
              Accessible drop-off: {option.accessible_dropoff.label}
            </p>
            <p className="mt-0.5 text-xs text-plum/70">
              Source: {option.accessible_dropoff.source} · {option.accessible_dropoff.verified ? 'verified' : 'NOT verified — confirm with campus'}
            </p>
          </div>
        )}

        <div className="mt-4"><SplitList option={option} /></div>

        {showReference && f.hypothetical_reference_fils !== undefined && (
          <p className="mt-4 rounded-xl bg-white p-3 text-xs text-plum/70">
            <b>Hypothetical reference:</b> the same route with 4 riders would cost {jod(f.hypothetical_reference_fils)} — an
            illustration, <b>not an available quote</b>.
            {f.delta_vs_reference_fils !== undefined && <> Your difference: <b>{jod(f.delta_vs_reference_fils, true)}</b>.</>}
          </p>
        )}

        {option.hard_filters_passed && option.hard_filters_passed.length > 0 && (
          <ul className="mt-3 flex flex-wrap gap-1.5" aria-label="Safety and accessibility filters never relaxed">
            {option.hard_filters_passed.map((h) => (
              <li key={h}><Chip tone="soft"><Check className="size-3" aria-hidden /> {h}</Chip></li>
            ))}
          </ul>
        )}
        {children && <div className="mt-4 space-y-2">{children}</div>}
      </div>
    </article>
  )
}
