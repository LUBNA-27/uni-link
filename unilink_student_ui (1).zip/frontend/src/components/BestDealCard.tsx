import { Sparkles } from 'lucide-react'
import { fmtJod, jod } from '../format'
import type { PlanOption } from '../types'
import { Button, Chip } from './ui'
import { RouteStrip, SplitList } from './BoardingPass'

/** Best Deal option: exactly ONE relaxed soft constraint, utility, deltas. Rendering only. */
export function BestDealCard({
  option, rank, onChoose, busy,
}: { option: PlanOption; rank: number; onChoose: (o: PlanOption) => void; busy?: boolean }) {
  const f = option.fare
  const top = rank === 0
  return (
    <article className={`overflow-hidden rounded-3xl bg-lavender text-plum shadow-lg ${top ? 'ring-4 ring-lime' : ''}`} aria-label={`Best Deal option ${rank + 1}`}>
      <header className="flex items-center justify-between bg-lime px-5 py-2 text-plum">
        <span className="inline-flex items-center gap-1.5 text-xs font-black tracking-[0.16em]">
          <Sparkles className="size-4" aria-hidden /> BEST DEAL {rank + 1}{top ? ' · TOP PICK' : ''}
        </span>
        {option.utility !== undefined && <span className="text-xs font-bold">score {option.utility.toFixed(2)}</span>}
      </header>

      <div className="p-5">
        <p className="text-xs font-bold uppercase text-plum/60">What we relaxed (one thing only)</p>
        <p className="text-xl font-black">{option.relaxed ?? 'Nothing — exact match'}</p>

        <div className="mt-4 grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs font-bold uppercase text-plum/60">Arrive</p>
            <p className="text-4xl font-black leading-none tabular-nums">{option.arrival}</p>
            <p className="mt-1 text-xs text-plum/60">leave home {option.leave_home}</p>
          </div>
          <div>
            <p className="text-xs font-bold uppercase text-plum/60">Your share</p>
            <p className="text-3xl font-black leading-none tabular-nums text-magenta">
              <span className="mr-1 text-sm font-extrabold">JOD</span>{fmtJod(f.your_share_fils)}
            </p>
            {f.delta_vs_reference_fils !== undefined && (
              <p className="mt-1 text-xs text-plum/60">
                {f.delta_vs_reference_fils === 0 ? 'Matches the reference' : `${jod(f.delta_vs_reference_fils, true)} vs reference`}
              </p>
            )}
          </div>
        </div>

        <div className="mt-4"><RouteStrip option={option} /></div>

        {f.hypothetical_reference_fils !== undefined && (
          <p className="mt-3 text-xs text-plum/60">
            Reference {jod(f.hypothetical_reference_fils)} = hypothetical same-route 4-rider price, <b>not an available quote</b>.
          </p>
        )}
        {f.shares && f.shares.length > 1 && (
          <details className="mt-3 rounded-xl bg-white p-2 text-sm">
            <summary className="min-h-10 cursor-pointer py-2 font-bold">See the fair split</summary>
            <SplitList option={option} />
          </details>
        )}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {option.hard_filters_passed?.map((h) => <Chip key={h} tone="soft">✓ {h}</Chip>)}
        </div>

        <Button className="mt-4" variant={top ? 'primary' : 'outline-lime'} busy={busy} onClick={() => onChoose(option)}>
          Choose this · {jod(f.your_share_fils)}
        </Button>
      </div>
    </article>
  )
}
