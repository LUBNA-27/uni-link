import { useEffect, useState } from 'react'
import { Accessibility, ArrowLeft, RefreshCw } from 'lucide-react'
import { api } from '../api'
import { useStore } from '../store'
import type { PlanOption } from '../types'
import { BoardingPass } from '../components/BoardingPass'
import { BestDealCard } from '../components/BestDealCard'
import { ConfirmSheet } from '../components/ConfirmSheet'
import { Button, Card, Chip, ErrorBox, Intro, MockChip } from '../components/ui'

export default function Journey() {
  const { request, plan, setPlan, sim, setSim, refreshSim, go } = useStore()
  const [chosen, setChosen] = useState<PlanOption | null>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState<unknown>()

  useEffect(() => { void refreshSim() }, [refreshSim])

  const replan = async () => {
    if (!request) return
    setBusy(true); setError(undefined); setChosen(null)
    try { setPlan(await api.plan(request)); await refreshSim() } catch (e) { setError(e) } finally { setBusy(false) }
  }

  if (!request || !plan) {
    return (
      <div className="space-y-4">
        <Intro title="No journey yet" text="Tell us about your trip first." />
        <Button onClick={() => go('trip')}>Plan a ride</Button>
      </div>
    )
  }

  // server says the world moved on since this plan was made
  const stale = sim !== undefined && sim.revision > plan.plan_revision && sim.trips.length === 0

  return (
    <div className="space-y-4">
      <button onClick={() => go('trip')} className="inline-flex items-center gap-1 text-sm font-bold text-white/80"><ArrowLeft className="size-4" aria-hidden /> Edit request</button>
      <div className="flex flex-wrap gap-2">
        <MockChip endpoint="plan" />
        <Chip tone="lime">{request.gender_pool === 'female_only' ? 'Female-only' : 'Male-only'}</Chip>
        <Chip tone="soft"><span className="text-white">Class {request.class_start} · {request.desired_companions} companions · cap {(request.fare_cap_fils / 1000).toFixed(2)} JOD</span></Chip>
      </div>

      {stale && (
        <div role="status" className="flex items-center justify-between gap-3 rounded-2xl bg-amber-100 p-3 text-sm text-plum">
          <span>This plan is out of date.</span>
          <button onClick={replan} className="inline-flex items-center gap-1 font-extrabold text-magenta"><RefreshCw className="size-4" aria-hidden /> Refresh</button>
        </div>
      )}
      <ErrorBox error={error} onRetry={replan} />

      {plan.status === 'exact_match' && plan.options[0] && (
        <>
          <Intro title="Exact match found" text="Everything you asked for, as requested." />
          <BoardingPass option={plan.options[0]} badge={<Chip tone="lime">EXACT MATCH</Chip>}>
            <Button busy={busy} onClick={() => setChosen(plan.options[0])}>Review & confirm</Button>
          </BoardingPass>
        </>
      )}

      {plan.status === 'best_deal_proposed' && (
        <>
          <Intro title="No exact match — here is your Best Deal" text="Your safety and accessibility rules stay. We relax exactly one flexible thing at a time." />
          {plan.options.map((o, i) => <BestDealCard key={o.plan_id} option={o} rank={i} busy={busy} onChoose={setChosen} />)}
          <p className="text-center text-xs text-white/60">Nothing is booked or charged until you confirm.</p>
        </>
      )}

      {(plan.status === 'no_feasible_route' || plan.status === 'no_accessible_route') && (
        <Card className="space-y-3 text-plum">
          <h2 className="flex items-center gap-2 text-xl font-black">
            {plan.status === 'no_accessible_route' && <Accessibility className="size-6 text-magenta" aria-hidden />}
            {plan.status === 'no_accessible_route' ? 'No accessible vehicle right now' : 'No route fits yet'}
          </h2>
          <p>{plan.reason?.message ?? 'We could not find a route that meets every rule you set.'}</p>
          {plan.assistance && <p className="rounded-xl bg-lime/50 p-3 text-sm font-semibold">{plan.assistance.message}</p>}
          <Button onClick={() => go('trip')}>Change my request</Button>
        </Card>
      )}

      <ConfirmSheet
        option={chosen}
        planRevision={plan.plan_revision}
        onClose={() => setChosen(null)}
        onStale={replan}
        onDone={async (r) => {
          setChosen(null)
          if (r.status === 'confirmed' || r.status === 'awaiting_consent') {
            try { setSim(await api.simState(r.session_id)) } catch { /* booked screen will retry */ }
            go('booked')
          }
        }}
      />
    </div>
  )
}
